%% IQ to vUS data processing, GPU-based data processing
% input:
    % IQ: beamformed quadrature data, [nz,nx,nt]
    % PRSSinfo: data processing information, including
        % PRSSinfo.FWHM: (X,Z) spatial resolution, Full Width at Half Maximum of point spread function, m
        % PRSSinfo.rFrame: DAQ frame rate, Hz
        % PRSSinfo.f0: Transducer center frequency, Hz
        % PRSSinfo.C: Sound speed in the sample, m/s
        % PRSSinfo.g1nT: g1 calculation sample number
        % PRSSinfo.g1nTau: maximum number of time lag
        % PRSSinfo.SVDrank: SVD rank [low high]
        % PRSSinfo.HPfC:  High pass filtering cutoff frequency, Hz
        % PRSSinfo.NEQ: do noise equalization? 0: no noise equalization; 1: apply noise equalization
        % PRSSinfo.rfnScale: spatial refind scale
        % PRSSinfo.useMsk: 1: use ULM data as spatial mask; 0: no spatial mask
        % PRSSinfo.ulmMsk: ULM-based spatial constrain mask
            % [nz,nx,3], 1: up flow (positive frequency); 
            % 2 down flow (negative frequency); 3: all flow 
            % ulmMsk=1 if PRSSinfo.useMsk=0
% output:
    % F: dynamic component fraction, [nz,nx,2], 2: [Descending,ascending]
    % Vz: axial-direction velocity component, [nz,nx,2], 2: [Descending,ascending], mm/s
    % V=sqrt(Vx.^2+Vz.^2), [nz,nx,2], 2: [Descending,ascending], mm/s
    % SigmaVz: Vz distribution (sigma-Vz), [nz,nx,2], 2: [Descending,ascending]
    % R: fitting accuracy, [nz,nx,2], 2: [Descending,ascending]
clear all; clc
addpath('./SubFunctions');
%% Use GPU calculation or not
useGPU = questdlg('Use GPU for data processing?', 'Select', ...
    'YES', 'NO', 'Cancel', 'Cancel');
%% Load data
disp(['Loading data, ', datestr(datetime('now'))]);
% load ('./DATA/phantomData5a.mat');  % angled flow, preset speed 5 mm/s
load ('./DATA/phantomData15a.mat');  % angled flow, preset speed 15 mm/s
% load ('./DATA/phantomData9t.mat');  % transverse flow, preset speed 9 mm/s
% load ('./DATA/phantomData25t.mat');  % transverse flow, preset speed 25 mm/s
% IQ: beamformed complex quadratue data
[nz,nx,nt]=size(IQ);
PRSSinfo.g1StartT=1;
PRSSinfo.g1nT=nt;
PRSSinfo.g1nTau=100;
PRSSinfo.rFrame=5000; % sIQ frame rate, Hz
PRSSinfo.SVDrank=[3, nt];
PRSSinfo.HPfC=25; % high pass frequency cutoff
PRSSinfo.FWHM=[125 100]*1e-6;  % (X, Z) spatial resolution, Full Width at Half Maximum of point spread function, m       
PRSSinfo.C=1540;                    % sound speed, m/s
PRSSinfo.f0=16.625*1e6;               % Transducer center frequency, Hz
PRSSinfo.rfnScale=1;
PRSSinfo.xCoor=interp(P.xCoor,PRSSinfo.rfnScale);
PRSSinfo.zCoor=interp(P.zCoor,PRSSinfo.rfnScale);
PRSSinfo.NEQ=0; % no noise equalization
%% Clutter rejection
disp(['Clutter Rejection - ', datestr(datetime('now'))]);
[sIQ, sIQHP, sIQHHP, eqNoise]=IQ2sIQ(IQ(:,:,1:PRSSinfo.g1nT),PRSSinfo); % 0: no noise equalization
[nz,nx,nt]=size(sIQ);
clear IQ
disp(['Power Doppler Processing - ', datestr(datetime('now'))]);
[PDI]=sIQ2PDI(sIQ);  % PDI processing
disp(['Color Doppler Processing - ', datestr(datetime('now'))]);
Vcz0=(ColorDoppler(sIQ,PRSSinfo)); % color Doppler, all frequency
disp(['g1-based vUS Processing - ', datestr(datetime('now'))]);
if strcmp(useGPU, 'YES')
    Dev=gpuDevice;
    disp('GPU-based vUS Processing ...(NOTE: it taks around 4 seconds)');
    tic;[F, Vz, Vx, V, R,CR]=sIQ2vUS_SV_GPU(sIQ, PRSSinfo);toc
else
    disp('CPU-based vUS Processing ...(NOTE: it taks around 30 seconds)');
    tic;[F, Vz, Vx, V, R,CR]=sIQ2vUS_SV(sIQ, PRSSinfo);toc
end
Vcz=imresize(Vcz0, [nz,nx]*PRSSinfo.rfnScale,'bilinear').*CR;
save(['./vUS.mat'],'-v7.3','F','Vz','V','R','pVz','PDI','PRSSinfo','P');
disp(['Results are saved! - ', datestr(datetime('now'))]);
%% figure plot
[VzCmap,VzCmapDn, VzCmapUp, PhtmCmap]=Colormaps_fUS;
Coor.x=[1:nx]*0.05/PRSSinfo.rfnScale;
Coor.z=[1:nz]*0.05/PRSSinfo.rfnScale;
Fig=figure;
set(Fig,'Position',[400 400 1700 350])
subplot(1,3,1)
h1=imagesc(Coor.x,Coor.z,abs(V)); 
colormap(PhtmCmap);
caxis([0 30]);
colorbar
axis equal tight;
xlabel('x [mm]')
ylabel('z [mm]')
title('vUS-V [mm/s]')

subplot(1,3,2)
h2=imagesc(Coor.x,Coor.z,abs(Vz)); 
colormap(PhtmCmap);
caxis([0 30]);
colorbar
axis equal tight;
xlabel('x [mm]')
ylabel('z [mm]')
title('vUS-Vz [mm/s]')

subplot(1,3,3)
h3=imagesc(Coor.x,Coor.z,abs(Vcz)); 
colormap(PhtmCmap);
caxis([0 30]);
colorbar
axis equal tight;
xlabel('x [mm]')
ylabel('z [mm]')
title('Color Doppler-Vz [mm/s]')

