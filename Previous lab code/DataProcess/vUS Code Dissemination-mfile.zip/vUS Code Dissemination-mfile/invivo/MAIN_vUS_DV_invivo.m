%% IQ to vUS data processing
% input:
    % IQ: beamformed quadrature data, [nz,nx,nt]
    % PRSSinfo: data processing information, including
        % PRSSinfo.FWHM: (X,Z) spatial resolution, Full Width at Half Maximum of point spread function, m
        % PRSSinfo.rFrame: DAQ frame rate, Hz
        % PRSSinfo.f0: Transducer center frequency, Hz
        % PRSSinfo.C: Sound speed in the sample, m/s
        % PRSSinfo.g1nT: g1 calculation sample number
        % PRSSinfo.g1nTau: maximum number of time lag
        % PRSSinfo.SVDrank: SVD rank [low high]
        % PRSSinfo.HPfC:  High pass filtering cutoff frequency, Hz
        % PRSSinfo.NEQ: do noise equalization? 0: no noise equalization; 1: apply noise equalization
        % PRSSinfo.rfnScale: spatial refind scale
        % PRSSinfo.useMsk: 1: use ULM data as spatial mask; 0: no spatial mask
        % PRSSinfo.ulmMsk: ULM-based spatial constrain mask
            % [nz,nx,3], 1: up flow (positive frequency); 
            % 2 down flow (negative frequency); 3: all flow 
            % ulmMsk=1 if PRSSinfo.useMsk=0
% output:
    % F: dynamic component fraction, [nz,nx,2], 2: [Descending,ascending]
    % Vz: axial-direction velocity component, [nz,nx,2], 2: [Descending,ascending], mm/s
    % V=sqrt(Vx.^2+Vz.^2), [nz,nx,2], 2: [Descending,ascending], mm/s
    % pVz: Vz distribution (sigma-Vz), [nz,nx,2], 2: [Descending,ascending]
    % R: fitting accuracy, [nz,nx,2], 2: [Descending,ascending]
clear all; clc
addpath('./SubFunctions/');
%% Use ULM spatial mask or not
useULMmsk = questdlg('Use ULM mask for vUS spatial constrain?', 'Select', ...
    'YES', 'NO', 'Cancel', 'Cancel');
%% Use GPU calculation or not
useGPU = questdlg('Use GPU for data processing?', 'Select', ...
    'YES', 'NO', 'Cancel', 'Cancel');
%% Load data
disp(['Loading data, ', datestr(datetime('now'))]);
load ('./DATA/invivoData.mat'); 
[nz,nx,nt]=size(IQ);
% IQ: beamformed complex quadratue data
% BB: microbubble accumuation map (resize to 25 um pixel size),
    % BB(:,:,1): up flow
    % BB(:,:,2): down flow
    % BB(:,:,3): all flow
% BBV: microbubble velocity map (resize to 25 um pixel size),
    % BBV(:,:,1): up flow
    % BBV(:,:,2): down flow
% BBVz: microbubble axial velocity map (resize to 25 um pixel size),
    % BBVz(:,:,1): up flow
    % BBVz(:,:,2): down flow
%% data processing parameters
if strcmp(useULMmsk, 'YES')
    PRSSinfo.useMsk=1;
    PRSSinfo.rfnScale=2;
    PRSSinfo.ulmMsk=[];
    for iBB=1:3
        PRSSinfo.ulmMsk(:,:,iBB)=(abs(BB(:,:,iBB))>1); % use ULM as spatial constrain mask
    end
else
    PRSSinfo.useMsk=0;
    PRSSinfo.ulmMsk=1;
    PRSSinfo.rfnScale=1;
end
PRSSinfo.g1StartT=1;
PRSSinfo.g1nT=nt;
PRSSinfo.g1nTau=100;
PRSSinfo.rFrame=5000; % sIQ frame rate, Hz
PRSSinfo.SVDrank=[25, nt];
PRSSinfo.HPfC=25; % high pass frequency cutoff
PRSSinfo.FWHM=[125 100]*1e-6;  % (X, Z) spatial resolution, Full Width at Half Maximum of point spread function, m       
PRSSinfo.C=1540;                    % sound speed, m/s
PRSSinfo.f0=16.625*1e6;               % Transducer center frequency, Hz
PRSSinfo.xCoor=interp(P.xCoor,PRSSinfo.rfnScale);
PRSSinfo.zCoor=interp(P.zCoor,PRSSinfo.rfnScale);
PRSSinfo.MpVz=1; % maximum p value for SigmaVz
PRSSinfo.NEQ=0; % no noise equalization
%% 1. Clutter rejection
disp(['Clutter Rejection - ', datestr(datetime('now'))]);
[sIQ, sIQHP, sIQHHP, eqNoise]=IQ2sIQ(IQ(:,:,1:PRSSinfo.g1nT),PRSSinfo); % 0: no noise equalization
[nz,nx,nt]=size(sIQ);
clear IQ
%% 2. vUS data processing
disp(['g1-based vUS Processing - ', datestr(datetime('now'))]);
if strcmp(useGPU, 'YES')
    disp('GPU-based vUS Processing ...(NOTE: it taks around 30 seconds)');
    tic;[F, Vz, V,  pVz, R]=sIQ2vUS_NPDV_GPU(sIQ, PRSSinfo);toc
else
    disp('CPU-based vUS Processing ...(NOTE: it taks around 400 seconds)');
    tic;[F, Vz, V,  pVz, R]=sIQ2vUS_NPDV(sIQ, PRSSinfo);toc
end
%% 3. save results and plot V and Vz
[VzCmap]=Colormaps_fUS;
save(['./vUS.mat'],'-v7.3','F','Vz','V','R','pVz');
disp(['Results are saved! - ', datestr(datetime('now'))]);
% figure plot
Coor.x=PRSSinfo.xCoor;     Coor.z=PRSSinfo.zCoor;
Fig=figure;
set(Fig, 'Position',[300 400 1300 400]);
subplot(1,2,1)
Fuse2Images(V(:,:,1),V(:,:,2),[-30 30],[-30 30],Coor.x,Coor.z,2.5);
title(['vUS, V [mm/s]']);
subplot(1,2,2)
Fuse2Images(Vz(:,:,1),Vz(:,:,2),[-30 30],[-30 30],Coor.x,Coor.z,2.5);
title(['vUS, Vz [mm/s]']);
%% plot PDI-based HSV velocity map
% figure;
% PLOTwtV(V,(PDIHHP).^0.4,Coor,[-30 30])
% title('vUS-V [mm/s]');